import React from 'react'
import Navbar from "../HomePage/Navbar"; 
function Profile() {
  return (

 <>
 <Navbar/>
 
 </>
  )
}

export default Profile