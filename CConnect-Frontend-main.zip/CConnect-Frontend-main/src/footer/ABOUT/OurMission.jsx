import Navbar from "../../HomePage/Navbar"

function OurMission(){
    return (
<Navbar/>
    )
}

export default OurMission;